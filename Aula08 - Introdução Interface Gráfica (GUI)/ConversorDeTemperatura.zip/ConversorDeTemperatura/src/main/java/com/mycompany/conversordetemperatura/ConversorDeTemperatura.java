package com.mycompany.conversordetemperatura;

import java.awt.*;
import javax.swing.*;

public class ConversorDeTemperatura {
    
    public static void criarTela(){
        // cria a tela
        JFrame tela = new JFrame("Conversor");
        // cria um campo de texto na tela
        JTextField celsiusTextField = new JTextField(10);
        // cria um texto não editável na tela
        JLabel celsiusLabel = new JLabel("\u00B0C");
        // cria um botão na tela
        JButton convertButton = new JButton("Converter");
        // texto não editável para apresentar o resultado
        JLabel valorConvertidoLabel = new JLabel("");
        
        // Cria um objeto da que representa um painel
        // de conteudos e atribui esse painel como sendo
        // o painel do objeto tela
        Container painelDeConteudo = tela.getContentPane();
        painelDeConteudo.setLayout (new GridLayout (2, 2, 4, 4));
        painelDeConteudo.add(celsiusTextField);
        painelDeConteudo.add(celsiusLabel);
        painelDeConteudo.add(convertButton);
        painelDeConteudo.add(valorConvertidoLabel); 
        
        // Programação do Evento de Click
        convertButton.addActionListener((e) -> {
            // entrada de dados
            double celsius = Double.parseDouble(
                celsiusTextField.getText()
            );  
            // processamento: cálculo de C pra F
            double fahrenheit = celsius / 5 * 9 + 32;
            // saída de dados
            valorConvertidoLabel.setText("\u00B0F" + 
                    fahrenheit);
        });
        
        // ajustar a tela de acordo com o conteudo
        tela.pack();
        // altera comportamento padrão do botão fechar
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // torna a tela visivel
        tela.setVisible(true);
        // centraliza a tela
        tela.setLocationRelativeTo(null);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater (() -> {
            criarTela();
        });
    }
}
